const express = require('express');
const Database = require('better-sqlite3');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ── DB SETUP ──
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'axios.db');
const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS estoque (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    grupo TEXT, cota TEXT, adm TEXT, investidor TEXT,
    credito REAL DEFAULT 0, parcela REAL DEFAULT 0, pago REAL DEFAULT 0,
    categoria TEXT, situacao TEXT, vcto TEXT,
    meses INTEGER DEFAULT 0, atraso INTEGER DEFAULT 0, obs TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS vendas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    adm TEXT, grupo TEXT, cota TEXT, credito REAL DEFAULT 0,
    vpago REAL DEFAULT 0, lance REAL DEFAULT 0, agil REAL DEFAULT 0,
    entrada REAL DEFAULT 0, parc_ant REAL DEFAULT 0, parc_nova REAL DEFAULT 0,
    pertence TEXT, cliente TEXT, pago_cli REAL DEFAULT 0,
    data TEXT, banco TEXT, vcto TEXT, status TEXT DEFAULT 'PENDENTE', obs TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS vendas_sem (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    grupo TEXT, cota TEXT, investidor TEXT, adm TEXT,
    credito REAL DEFAULT 0, parcela REAL DEFAULT 0,
    categoria TEXT, vendedor TEXT, meses INTEGER DEFAULT 0, vcto TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS caixa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT, data TEXT, descricao TEXT, cat TEXT,
    valor REAL DEFAULT 0, status TEXT, mes TEXT, obs TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS investidores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT, contrato TEXT, adm TEXT, grupo TEXT, cota TEXT,
    credito REAL DEFAULT 0, parcela REAL DEFAULT 0, prazo INTEGER DEFAULT 0,
    lance REAL DEFAULT 0, comissao REAL DEFAULT 0.02,
    status TEXT DEFAULT 'ATIVO', obs TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Seed initial data if tables are empty
const count = db.prepare('SELECT COUNT(*) as n FROM estoque').get();
if (count.n === 0) {
  const seedEstoque = db.prepare(`INSERT INTO estoque (grupo,cota,adm,investidor,credito,parcela,pago,categoria,situacao,vcto,meses,atraso,obs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const seedMany = db.transaction((rows) => { rows.forEach(r => seedEstoque.run(...r)); });
  seedMany([
    ['9010','767','YAMAHA','DANIEL',28425,722.29,1441.38,'MOTO','CONTEMPLADA','2026-03-12',50,0,''],
    ['9024','130','YAMAHA','ANAJAIRA',170000,2118.57,4237.14,'CARRO','S/ CONTEM','2026-03-12',68,2,'Sustentação'],
    ['8090','541','YAMAHA','ALINE',25893,879.48,2638.56,'MOTO','S/ CONTEM','2026-03-20',33,0,''],
    ['9052','733','YAMAHA','WENDEL',18925,883.63,1769.81,'MOTO','CONTEMPLADA','2026-03-20',24,0,''],
    ['9052','1167','YAMAHA','WENDEL',18925,883.63,1769.81,'MOTO','S/ CONTEM','2026-03-20',24,0,''],
    ['8076','195','YAMAHA','WENDEL',38000,1245.5,1245.5,'CARRO','S/ CONTEM','2026-03-12',34,0,''],
    ['9005','490','YAMAHA','ALINE',23112,584.08,1752.48,'MOTO','S/ CONTEM','2026-03-20',48,0,''],
    ['8095','207','YAMAHA','DANIEL',41514,1055.84,2111.68,'CARRO','CONTEMPLADA','2026-03-20',44,0,''],
  ]);

  const seedVenda = db.prepare(`INSERT INTO vendas (adm,grupo,cota,credito,vpago,lance,agil,entrada,parc_ant,parc_nova,pertence,cliente,pago_cli,data,banco,vcto,status,obs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  seedVenda.run('YAMAHA','8088','450',21769.35,873.41,8363.46,500,9736.87,873.41,529.69,'DANIEL','JOSÉ',8363.46,'2025-07-16','ITAU D. L. LINO','7','PENDENTE','');
  seedVenda.run('YAMAHA','8086','762',17680.85,708.55,6497.55,1000,8206.10,709.37,439.58,'ALINE','AFONSO',8200,'2025-07-18','ITAU D. L. LINO','12','QUITADO','');
  seedVenda.run('YAMAHA','8090','303',21789.75,1379.46,8818.90,200,10398.36,689.73,420,'ALINE','MAYKON',23860,'2025-09-30','ITAU D. L. LINO','20','QUITADO','');

  const seedVSem = db.prepare(`INSERT INTO vendas_sem (grupo,cota,investidor,adm,credito,parcela,categoria,vendedor,meses,vcto) VALUES (?,?,?,?,?,?,?,?,?,?)`);
  seedVSem.run('9547','8','BRUNO KOITI','YAMAHA',85518,1409.27,'MOTO','TIAGO/ DANIEL',71,'20');
  seedVSem.run('10017','455','CLEBER SCOPARIN','YAMAHA',400000,1491.35,'IMÓVEL','DANIEL',238,'16');
  seedVSem.run('10001','82','WILLAN','YAMAHA',200000,2031.74,'IMÓVEL','WILLIAN',0,'16');

  const seedCaixa = db.prepare(`INSERT INTO caixa (tipo,data,descricao,cat,valor,status,mes,obs) VALUES (?,?,?,?,?,?,?,?)`);
  [
    ['RECEITA','2025-12-04','COMISSAO YAMAHA','COMISSÃO',11207.64,'PG','DEZ/2025',''],
    ['RECEITA','2025-12-18','COMISSAO YAMAHA','COMISSÃO',15909.61,'PG','DEZ/2025',''],
    ['RECEITA','2025-12-08','VENDA CARTA','VENDA CARTA',22890,'PG','DEZ/2025',''],
    ['DESPESA','2025-12-05','SALARIO PAULO','FIXO',2000,'PG','DEZ/2025',''],
    ['DESPESA','2025-12-15','ALUGUEL','FIXO',1050,'PG','DEZ/2025',''],
    ['RECEITA','2026-01-06','COMISSAO YAMAHA','COMISSÃO',30315.64,'PG','JAN/2026',''],
    ['RECEITA','2026-01-02','VENDA BRUNO','VENDA CARTA',19900,'PG','JAN/2026',''],
    ['DESPESA','2026-01-22','SALARIO PAULO','FIXO',2500,'PG','JAN/2026',''],
    ['DESPESA','2026-01-02','LANCE CARTA BRUNO','LANCE',7185.59,'PG','JAN/2026',''],
    ['RECEITA','2026-02-02','VENDA DENILSON','VENDA CARTA',20200,'PG','FEV/2026',''],
    ['RECEITA','2026-02-05','COMISSAO YAMAHA','COMISSÃO',19454.28,'PG','FEV/2026',''],
    ['DESPESA','2026-02-02','ALUGUEL','FIXO',5000,'PG','FEV/2026',''],
    ['DESPESA','2026-02-02','GRAZI ITAU','OUTRO',11200,'PG','FEV/2026',''],
    ['RECEITA','2026-03-05','COMISSÃO YAMAHA','COMISSÃO',12354.93,'PG','MAR/2026',''],
    ['DESPESA','2026-03-05','ALUGUEL','FIXO',5000,'PG','MAR/2026',''],
    ['DESPESA','2026-03-06','PAGAMENTO LANCE 8081','LANCE',12419.52,'PG','MAR/2026',''],
  ].forEach(r => seedCaixa.run(...r));

  const seedInv = db.prepare(`INSERT INTO investidores (nome,contrato,adm,grupo,cota,credito,parcela,prazo,lance,comissao,status,obs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  seedInv.run('ALINE','20534149','YAMAHA','8084','112',46000,1466.42,36,0,0.02,'ATIVO','');
  seedInv.run('ALINE','20534150','YAMAHA','8091','242',73647,2347.75,36,0,0.02,'ATIVO','');
  seedInv.run('DANIEL','20533859','YAMAHA','8099','102',46000,1195.23,45,0,0.02,'ATIVO','');
  seedInv.run('DANIEL','20533868','YAMAHA','9005','563',20760,549.42,48,0,0.02,'ATIVO','');
}

// ── MIDDLEWARE ──
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── GENERIC CRUD FACTORY ──
function crud(table, fields) {
  const router = express.Router();

  router.get('/', (req, res) => {
    try {
      const rows = db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all();
      res.json(rows);
    } catch(e) { res.status(500).json({ error: e.message }); }
  });

  router.post('/', (req, res) => {
    try {
      const vals = fields.map(f => req.body[f] ?? null);
      const stmt = db.prepare(`INSERT INTO ${table} (${fields.join(',')}) VALUES (${fields.map(()=>'?').join(',')})`);
      const result = stmt.run(...vals);
      const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(result.lastInsertRowid);
      res.json(row);
    } catch(e) { res.status(500).json({ error: e.message }); }
  });

  router.put('/:id', (req, res) => {
    try {
      const sets = fields.map(f => `${f} = ?`).join(', ');
      const vals = [...fields.map(f => req.body[f] ?? null), req.params.id];
      db.prepare(`UPDATE ${table} SET ${sets} WHERE id = ?`).run(...vals);
      const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
      res.json(row);
    } catch(e) { res.status(500).json({ error: e.message }); }
  });

  router.delete('/:id', (req, res) => {
    try {
      db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(req.params.id);
      res.json({ ok: true });
    } catch(e) { res.status(500).json({ error: e.message }); }
  });

  return router;
}

// ── ROUTES ──
app.use('/api/estoque', crud('estoque', ['grupo','cota','adm','investidor','credito','parcela','pago','categoria','situacao','vcto','meses','atraso','obs']));
app.use('/api/vendas', crud('vendas', ['adm','grupo','cota','credito','vpago','lance','agil','entrada','parc_ant','parc_nova','pertence','cliente','pago_cli','data','banco','vcto','status','obs']));
app.use('/api/vendas_sem', crud('vendas_sem', ['grupo','cota','investidor','adm','credito','parcela','categoria','vendedor','meses','vcto']));
app.use('/api/caixa', crud('caixa', ['tipo','data','descricao','cat','valor','status','mes','obs']));
app.use('/api/investidores', crud('investidores', ['nome','contrato','adm','grupo','cota','credito','parcela','prazo','lance','comissao','status','obs']));

// Export all data
app.get('/api/export', (req, res) => {
  const data = {
    estoque: db.prepare('SELECT * FROM estoque').all(),
    vendas: db.prepare('SELECT * FROM vendas').all(),
    vendasSem: db.prepare('SELECT * FROM vendas_sem').all(),
    caixa: db.prepare('SELECT * FROM caixa').all(),
    investidores: db.prepare('SELECT * FROM investidores').all(),
    exportedAt: new Date().toISOString()
  };
  res.setHeader('Content-Disposition', `attachment; filename="axios_backup_${new Date().toISOString().split('T')[0]}.json"`);
  res.json(data);
});

// Health check
app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// Serve frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✅ Axios Sistema rodando na porta ${PORT}`);
});
